from interface_sub import subjects
if __name__ == '__main__':
    subjects()